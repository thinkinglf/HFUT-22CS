package server;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.io.IOException;
import java.net.ServerSocket;

public class serverDemo extends JFrame {
    JButton send_botton;
    JTextArea out = new JTextArea(1, 30);
    JTextArea in = new JTextArea(15, 30);
    JPanel pan = new JPanel();


    public serverDemo() {
        super("Server");
        Border border = BorderFactory.createLineBorder(Color.blue, 1);
        in.setBorder(border);
        out.setBorder(border);
        send_botton = new JButton("公告");

        pan.setLayout(new FlowLayout());
        pan.add(in);
        pan.add(out);
        pan.add(send_botton);

        add(pan);
        setSize(350, 370);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


        try {
            ServerSocket serverInter1 = new ServerSocket(6666);
            ServerSocket serverInter2 = new ServerSocket(6667);
            ServerSocket serverInter3 = new ServerSocket(6668);

            baseThread thread1 = new baseThread(serverInter1, in, out, send_botton);
            thread1.setName("user1");
            thread1.start();
            baseThread thread2 = new baseThread(serverInter2, in, out, send_botton);
            thread2.setName("user2");
            thread2.start();
            baseThread thread3 = new baseThread(serverInter3, in, out, send_botton);
            thread3.setName("user3");
            thread3.start();
            temporaryLink thread0 = new temporaryLink();
            thread0.start();
        } catch (IOException e) {
            System.out.println("Error:" + e);
        }
    }

    public static void main(String[] args) {
        new serverDemo();
    }

}
