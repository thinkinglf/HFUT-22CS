package server;

import java.io.OutputStream;

public class sockets {
    // 存储每个客户端的输出流
    public static OutputStream[] outStreams = new OutputStream[10];

    // 跟踪当前存储的输出流数量
    public static int index_serverOut;

    // 存储每个客户端的名称（线程名称）
    public static String[] names = new String[10];

    public sockets(OutputStream outStream, String name) {
        // 将客户端名称存储到数组
        names[index_serverOut] = name;

        // 将客户端的输出流存储到数组，并更新索引
        outStreams[index_serverOut++] = outStream;
    }
}
