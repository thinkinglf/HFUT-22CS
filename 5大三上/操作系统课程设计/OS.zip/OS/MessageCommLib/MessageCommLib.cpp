﻿// MessageCommLib.cpp : 定义静态库的函数。
//

#include "pch.h"
#include "framework.h"
#include "message_comm.h"

// 创建命名管道（服务器用）
HANDLE createPipe() {
    HANDLE hPipe = CreateNamedPipe(
        PIPE_NAME,
        PIPE_ACCESS_DUPLEX,
        PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
        PIPE_UNLIMITED_INSTANCES,
        MAX_MESSAGE_SIZE,
        MAX_MESSAGE_SIZE,
        0,
        NULL);

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("[ERROR] 创建管道失败, 错误码: %lu\n", GetLastError());
    }
    return hPipe;
}

// 连接命名管道（客户端用）
HANDLE connectToPipe() {
    HANDLE hPipe = CreateFile(
        PIPE_NAME,
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        0,
        NULL);

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("[ERROR] 连接管道失败, 错误码: %lu\n", GetLastError());
    }
    return hPipe;
}

// 发送消息
BOOL sendMessage(HANDLE hPipe, Message* msg) {
    DWORD bytesWritten;
    BOOL result = WriteFile(hPipe, msg, sizeof(Message), &bytesWritten, NULL);
    if (!result) {
        printf("[ERROR] 消息发送失败, 错误码: %lu\n", GetLastError());
    }
    return result;
}

// 接收消息
BOOL receiveMessage(HANDLE hPipe, Message* msg) {
    DWORD bytesRead;
    BOOL result = ReadFile(hPipe, msg, sizeof(Message), &bytesRead, NULL);
    if (!result || bytesRead == 0) {
        printf("[ERROR] 消息接收失败, 错误码: %lu\n", GetLastError());
    }
    return result;
}

// 关闭管道
void closePipe(HANDLE hPipe) {
    CloseHandle(hPipe);
}

