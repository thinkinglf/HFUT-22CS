﻿#include "message_comm.h"

int main() {
    // 创建命名管道（服务器端）
    HANDLE hPipe = createPipe();
    if (hPipe == INVALID_HANDLE_VALUE) {
        return -1;
    }

    printf("[INFO] 服务器正在等待客户端连接...\n");

    // 等待客户端连接
    BOOL isConnected = ConnectNamedPipe(hPipe, NULL);
    if (!isConnected) {
        printf("[ERROR] 客户端连接失败, 错误码: %lu\n", GetLastError());
        closePipe(hPipe);
        return -1;
    }

    printf("[INFO] 客户端已连接.\n");

    // 服务器端循环接收和处理消息
    Message msg;
    while (1) {
        // 接收消息
        BOOL result = receiveMessage(hPipe, &msg);
        if (!result) {
            break;
        }

        // 输出接收到的消息
        printf("[INFO] 接收到消息: %s (ID: %d)\n", msg.message, msg.id);

        // 如果客户端发送退出消息，断开连接并结束服务
        if (strncmp(msg.message, "exit", 4) == 0) {
            printf("[INFO] 客户端请求断开连接，结束服务.\n");
            break;
        }

        // 发送响应消息
        snprintf(msg.message, MAX_MESSAGE_SIZE, "消息已接收");
        if (!sendMessage(hPipe, &msg)) {
            printf("[ERROR] 响应消息发送失败.\n");
            break;
        }
    }

    // 关闭管道
    closePipe(hPipe);
    printf("[INFO] 服务器已结束服务.\n");

    return 0;
}
