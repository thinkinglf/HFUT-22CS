﻿#include "message_comm.h"

int main() {
    // 连接到命名管道（客户端）
    HANDLE hPipe = connectToPipe();
    if (hPipe == INVALID_HANDLE_VALUE) {
        return 1;
    }

    printf("[INFO] 已连接到服务器.\n");

    Message msg;
    int id = 1;
    while (1) {
        // 手动输入消息
        printf("[请输入消息]: ");
        fgets(msg.message, MAX_MESSAGE_SIZE, stdin);
        msg.message[strcspn(msg.message, "\n")] = '\0';  // 去掉换行符
        msg.id = id++;
        msg.timestamp = time(NULL);

        // 发送消息
        if (!sendMessage(hPipe, &msg)) {
            printf("[ERROR] 消息发送失败.\n");
            break;
        }

        printf("[INFO] 消息已发送: %s (ID: %d)\n", msg.message, msg.id);

        // 如果输入 "exit"，客户端结束
        if (strncmp(msg.message, "exit", 4) == 0) {
            break;
        }

        // 接收服务器的响应
        Message response;
        if (receiveMessage(hPipe, &response)) {
            printf("[INFO] 从服务器接收到响应: %s\n", response.message);
        }
    }

    // 关闭管道
    closePipe(hPipe);

    return 0;
}
