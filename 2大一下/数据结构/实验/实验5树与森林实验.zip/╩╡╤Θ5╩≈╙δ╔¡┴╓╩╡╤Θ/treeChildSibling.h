#pragma once
#include "creat.h"
#include <iostream>
using namespace std;
typedef char elementType;
void onexian(csTree s)
{
	if (s)
	{
		cout << s->data << " ";
		onexian(s->firstChild);
		onexian(s->nextSibling);
	}
}
void onehou(csTree s)
{
	if (s)
	{
		onehou(s->firstChild);
		cout << s->data << " ";
		onehou(s->nextSibling);
	}
}
void onecengci(csTree s)
{
	//ģ�����
	int front = 0, rear = 0;
	csTree a[100];
	csTree temp;
	for (s; s; s = s->nextSibling)
	{
		a[++rear] = s;
	}
	while (front != rear)
	{
		temp = a[++front];
		cout << temp->data << " ";
		for (temp = temp->firstChild; temp; temp = temp->nextSibling)
		{
			a[++rear] = temp;
		}
	}
}
void two(csTree s, int& n, int count)
{
	if (s)
	{
		if (n < count)
		{
			n = count;
		}
		two(s->firstChild, n, count + 1);
		two(s->nextSibling, n, count);
	}
}
void three(csTree s, int& n)
{
	if (s)
	{
		if (s->firstChild == NULL)
		{
			n++;
		}
		three(s->firstChild, n);
		three(s->nextSibling, n);
	}
}
void four(csTree s, int& n, int count)
{
	if (s)
	{
		if (n < count)
		{
			n = count;
		}
		four(s->firstChild, n, 1);
		four(s->nextSibling, n, count + 1);
	}
}
void five(csTree s, int count)
{
	if (s)
	{
		cout << "( " << s->data << ", " << count << " )" << " ";
		five(s->firstChild, count + 1);
		five(s->nextSibling, count);
	}
}
void six1(csTree s, csTree& head)
{
	if (s)
	{
		cout << s->data;
		if (s->firstChild)
		{
			cout << "(";
		}
		six1(s->firstChild, head);
		if (s->nextSibling)
		{
			cout << ",";
		}
		if (s->nextSibling == NULL)
		{
			cout << ")";
		}
		if (s != head)
			six1(s->nextSibling, head);
	}
}
void six(csTree s)
{
	for (; s; s = s->nextSibling)
	{
		six1(s, s);
	}
}
