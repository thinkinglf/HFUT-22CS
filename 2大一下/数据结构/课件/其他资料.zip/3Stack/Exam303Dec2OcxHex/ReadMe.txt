========================================================================
       CONSOLE APPLICATION : Exam303Dec2OcxHex
========================================================================


AppWizard has created this Exam303Dec2OcxHex application for you.  

This file contains a summary of what you will find in each of the files that
make up your Exam303Dec2OcxHex application.

Exam303Dec2OcxHex.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

Exam303Dec2OcxHex.cpp
    This is the main application source file.


/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named Exam303Dec2OcxHex.pch and a precompiled types file named StdAfx.obj.


/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
