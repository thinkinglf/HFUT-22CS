// 505Recursion3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "iostream.h"

int B(int w)
{
     int y=50;    
     return y+w;
}

int A(int n)
{
      int x=10;
      x=B(x+n);    
      return x+n;
}


int main(int argc, char* argv[])
{
	int m=5;
    m=A(m);
	cout<<m;

	return 0;
}
