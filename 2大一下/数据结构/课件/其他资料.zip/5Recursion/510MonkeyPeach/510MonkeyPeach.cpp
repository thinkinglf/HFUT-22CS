// 510MonkeyPeach.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "iostream.h"

//��t=1��ʼ�����һ��t=10
int MonkeyPeach(int t)
{
	if(t==10)
		return 1;
	else
		return 2*(MonkeyPeach(t+1)+1);
}

//��t=10��ʼ�����һ��t=1
int MonkeyPeach1(int t)
{
	if(t==1)
		return 1;
	else
		return 2*(MonkeyPeach1(t-1)+1);
}


int main(int argc, char* argv[])
{
	cout<<MonkeyPeach(1)<<endl;
	cout<<MonkeyPeach1(10)<<endl;
	return 0;
}

