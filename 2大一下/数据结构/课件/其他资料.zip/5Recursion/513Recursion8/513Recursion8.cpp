// 513Recursion8.cpp : Defines the entry point for the console application.
//

//��ӵݹ����

#include "stdafx.h"
#include "iostream.h"

void P1(int n);
void P2(int n);

void P1(int n)
{
	if(n>0)
	{
		if(n%2==1)
		{
			P1(n-1);
			cout<<n<<" ";
		}
		else
		{
			cout<<n<<" ";
			P2(n-1);
		}
	}
}

void P2(int n)
{
	if(n>0)
	{
		if(n%3==0)
		{
			cout<<n<<" ";
			P1(n-1);
		}
		else
		{
			P2(n-1);
			cout<<n<<" ";
		}
	}
}


int main(int argc, char* argv[])
{
	int n;
	cout<<"������һ��������n=";
	cin>>n;

	P1(n);
	cout<<endl;

	P2(n);

	cout<<endl;
	
	return 0;
}
