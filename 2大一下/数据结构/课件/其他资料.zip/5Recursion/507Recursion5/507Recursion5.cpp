// 507Recursion5.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#include "iostream.h"

void A();
void B();
void AB();

void A()
{
	cout<<"A ";
}
void B()
{
	cout<<"B ";
	A();
	cout<<"B ";
}
void AB()
{
	cout<<"AB ";
	A();
	B();
	cout<<"AB ";
}

int main(int argc, char* argv[])
{
	AB();

	cout<<endl;
	
	return 0;
}

