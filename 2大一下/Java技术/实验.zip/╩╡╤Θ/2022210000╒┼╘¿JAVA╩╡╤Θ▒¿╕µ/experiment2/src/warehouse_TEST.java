import java.io.*;
import java.util.Comparator;
import java.util.Objects;
import java.util.Vector;

public class warehouse_TEST {
    public static void main(String[] args) throws IOException {
        //首先打开inventory 将文件内容存入arraylist静态成员中

        //File file_in = new File("D:\\000JAVA\\experiment2\\src\\Inventory.txt");
        //BufferedReader br_in = new BufferedReader(new FileReader(file_in));
        //(两种不同的创建方式)
        BufferedReader br_in = new BufferedReader(new FileReader("D:\\000JAVA\\experiment2\\src\\Inventory.txt"));
        String line_in;
        while ((line_in = br_in.readLine()) != null) {
            String[] buff_in = line_in.split("\\s+");
            Inventory.Ivy.add(new Inventory(buff_in[0], Integer.parseInt(buff_in[1]), buff_in[2], buff_in[3]));
        }
        br_in.close();

        //现在打开transactions进行文件的读取，并且存进vector<String[]>里
        Vector<String[]> vec = new Vector<>();
        BufferedReader br_tran = new BufferedReader(new FileReader("D:\\000JAVA\\experiment2\\src\\Transactions.txt"));
        String line_tran;
        while ((line_tran = br_tran.readLine()) != null) {
            String[] buff_tran = line_tran.split("\\s+");
            vec.add(buff_tran);
        }
        br_tran.close();

        //创建输出流，准备进行shipping文件和error文件输出
        BufferedWriter bw_sh = new BufferedWriter(new FileWriter("D:\\000JAVA\\experiment2\\src\\Shipping.txt"));
        BufferedWriter bw_er = new BufferedWriter(new FileWriter("D:\\000JAVA\\experiment2\\src\\Error.txt"));

        //首先处理A订单   在'A'后面是Item number，供应商supplier以及货物的描述description
        for (String[] strings : vec) {
            if (Objects.equals(strings[0], "A")) {
                Inventory.Ivy.add(new Inventory(strings[1], 0, strings[2], strings[3]));
            }
        }

        //然后处理R订单   在'R'后面是Item number和它的数量Quanlity
        for (String[] strings : vec) {
            if (Objects.equals(strings[0], "R")) {
                for (Inventory inventory : Inventory.Ivy) {
                    if (Objects.equals(inventory.m_Item_number, strings[1]))
                        inventory.m_Quantity += Integer.parseInt(strings[2]);
                }
            }
        }

        //然后处理O订单  一共分三步处理
        //第一步，先把所有的O订单存起来，并进行排序
        Vector<Integer> vec_O_index = new Vector<>();
        for (int i = 0; i < vec.size(); i++) {
            if (Objects.equals(vec.get(i)[0], "O")) {
                //当O订单中有元素
                for (int j = 0; j < vec_O_index.size(); j++) {
                    //当序号相等 分为两类大情况  1. 数量大于当前元素   2. 数量小于当前元素
                    //第一： 当前查找的已经是最后一个vec_O容器中内容
                    //第二： 后一个item序号与当前这个不同
                    //第三： 前后数量大小比较结果相反
                    if (Objects.equals(vec.get(vec_O_index.get(j))[1], vec.get(i)[1])) {
                        if (Integer.parseInt(vec.get(vec_O_index.get(j))[2]) < Integer.parseInt(vec.get(i)[2])) {
                            if (j == vec_O_index.size() - 1 || !Objects.equals(vec.get(vec_O_index.get(j + 1))[1], vec.get(i)[1]) ||
                                    Integer.parseInt(vec.get(vec_O_index.get(j + 1))[2]) > Integer.parseInt(vec.get(i)[2])) {
                                vec_O_index.add(j + 1, i);
                                break;
                            }
                        } else {
                            vec_O_index.add(j, i);
                            break;
                        }
                        //当其他订单中没有相同的元素
                    } else if (j == vec_O_index.size() - 1) {
                        vec_O_index.add(i);
                        break;
                    }
                }
                //如果当O订单集合里无元素（第一次）
                if (vec_O_index.size() == 0)
                    vec_O_index.add(i);
            }
        }

        //第二步：处理O订单
        bw_er.write("货物进销管理产生Error信息如下：");
        bw_er.newLine();
        bw_er.flush();
        Vector<Integer> vec_sh_index = new Vector<>();
        for (Integer index : vec_O_index) {
            for (Inventory inventory : Inventory.Ivy) {
                if (Objects.equals(vec.get(index)[1], inventory.m_Item_number)) {
                    if (inventory.m_Quantity > Integer.parseInt(vec.get(index)[2])) {
                        inventory.m_Quantity -= Integer.parseInt(vec.get(index)[2]);
                        //存储并合并准备输出的shipping信息：
                        for (int i = 0; i < vec_sh_index.size(); i++) {
                            //如果两个货物订单的货物编号与客户编号相同 则进行出货订单合并
                            if (Objects.equals(vec.get(index)[1], vec.get(vec_sh_index.get(i))[1]) && Objects.equals(vec.get(index)[3], vec.get(vec_sh_index.get(i))[3])) {
                                vec.get(vec_sh_index.get(i))[2] = String.valueOf(Integer.parseInt(vec.get(index)[2]) + Integer.parseInt(vec.get(vec_sh_index.get(i))[2]));
                            } else if (i == vec_sh_index.size() - 1) {
                                vec_sh_index.add(index);
                                break;
                            }
                        }
                        if (vec_sh_index.size() == 0) {
                            vec_sh_index.add(index);
                        }
                    } else {
                        //输出error信息
                        bw_er.write("货物编号：" + vec.get(index)[1] + " 发货数量不足，客户编号： " + vec.get(index)[3] + "\n");
                        bw_er.flush();
                    }
                    break;
                }
            }
        }

        //第三步：一起输出shipping信息
        bw_sh.write("货物进销管理产生shipping信息如下：");
        bw_sh.newLine();
        for (Integer index : vec_sh_index) {// %-8s 指一个宽度为8个字符（-表示左对齐，没有则表示右对齐），任何字符都会被显示在8个字符宽的字符内，
            bw_sh.write("货物编号：" + String.format("%-8s", vec.get(index)[1]) + "\t出货数量：" + String.format("%-8s", vec.get(index)[2]) + "\t客户：" + String.format("%-8s", vec.get(index)[3]) + "\n");
            bw_sh.flush();
        }

        //最后处理D订单
        for (String[] strings : vec) {
            if (Objects.equals(strings[0], "D")) {
                for (int i = 0; i < Inventory.Ivy.size(); i++) {
                    if (Objects.equals(Inventory.Ivy.get(i).m_Item_number, strings[1])) {
                        if (Inventory.Ivy.get(i).m_Quantity == 0)
                            Inventory.Ivy.remove(i);
                        else {
                            //输出error信息:
                            bw_er.write("编号： " + strings[1] + " 还有存货，不可删除货物信息\n");
                            bw_er.flush();
                            break;
                        }
                    }

                }
            }
        }
        bw_sh.close();
        bw_er.close();

        BufferedWriter bw_newIn = new BufferedWriter(new FileWriter("D:\\000JAVA\\experiment2\\src\\NewInventory.txt"));
        bw_newIn.write("货物进销管理产生shipping信息如下：\n货物编号\t" + "数量  \t" + "供货商 \t" + "货物描述\n");
        for (Inventory inventory : Inventory.Ivy) {
            bw_newIn.write(String.format("%-8s", inventory.m_Item_number) + String.format("%-8s", inventory.m_Quantity)
                    + String.format("%-8s", inventory.m_Supplier) + String.format("%-8s", inventory.m_Description) + "\n");
            bw_newIn.flush();
        }
        bw_newIn.close();
        System.out.println("货物进销系统表单更新完毕，文件已在对应位置生成已生成");
    }
}