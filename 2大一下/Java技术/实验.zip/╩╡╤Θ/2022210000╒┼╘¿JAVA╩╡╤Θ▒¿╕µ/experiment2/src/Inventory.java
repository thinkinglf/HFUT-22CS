import java.util.ArrayList;

public class Inventory {

    static ArrayList<Inventory> Ivy = new ArrayList<>();
    String m_Item_number;//货物编号
    int m_Quantity;//货物数量
    String m_Supplier;//供应商编号
    String m_Description;//货物描述

    public Inventory(String Item_number, int Quantity, String Supplier, String Description) {
        this.m_Item_number = Item_number;
        this.m_Quantity = Quantity;
        this.m_Supplier = Supplier;
        this.m_Description = Description;
    }

}