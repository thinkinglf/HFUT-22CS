package experment1test05;

import java.util.Scanner;

public class Point3D extends Point2D {
    public int z;

    Point3D() {
    }

    Point3D(int x, int y, int z) {//构造方法1
        super(x, y);
        this.z = z;
    }

    public void setZ(int z) {
        this.z = z;
    }

    public int getZ() {
        return z;
    }

    Point3D(Point2D p, int z) {//构造方法2
        super(p.getX(), p.getY());
        this.z = z;
    }

    public void offset(int a, int b, int c) {//3D点进行平移
        super.offset(a, b);
        z += c;
        System.out.println("改点平移后的坐标是(" + x + "," + y + "," + z + ")");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("请输入点p2d1的坐标");
        Point2D p2d1 = new Point2D(sc.nextInt(), sc.nextInt());
        System.out.println("请输入点p2d2的坐标");
        Point2D p2d2 = new Point2D(sc.nextInt(), sc.nextInt());

        double length2D = mathmethod.distance2D(p2d1, p2d2);//静态方法可以直接使用类名调用(也可以使用对象名调用，但不推荐使用)
        System.out.println("p2d1和p2d2两点之间的距离是：" + length2D);

        System.out.println("请输入点p3d1的坐标");
        Point3D p3d1 = new Point3D(sc.nextInt(), sc.nextInt(), sc.nextInt());
        System.out.println("请输入点p3d2的坐标");
        Point3D p3d2 = new Point3D(sc.nextInt(), sc.nextInt(), sc.nextInt());

        double length3D = mathmethod.distance3D(p3d1, p3d2);
        System.out.println("p3d1和p3d2两点之间的距离是：" + length3D);
    }
}
