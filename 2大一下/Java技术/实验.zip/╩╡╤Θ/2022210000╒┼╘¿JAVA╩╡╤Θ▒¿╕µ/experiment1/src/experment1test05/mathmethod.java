package experment1test05;

import java.util.Formatter;

public class mathmethod {
    public static double distance2D(Point2D p2d1, Point2D p2d2) {
        double distance;
        double x, y;
        x = Math.pow((p2d1.getX() - p2d2.getX()), 2);
        y = Math.pow((p2d1.getY() - p2d2.getY()), 2);
        distance = Math.sqrt(x + y);

        Formatter format = new Formatter().format("%.3f", distance);//使结果距离保留三位小数
        // String.valueOf()和.toString方法都能转换为String，不过String.valueOf()更常用
        distance = Double.parseDouble(String.valueOf(format));

        return distance;
    }

    public static double distance3D(Point3D p3d1, Point3D p3d2) {
        double distance;
        double x, y, z;
        x = Math.pow((p3d1.getX() - p3d2.getX()), 2);
        y = Math.pow((p3d1.getY() - p3d2.getY()), 2);
        z = Math.pow((p3d1.getZ() - p3d2.getZ()), 2);
        distance = Math.sqrt(x + y + z);

        Formatter format = new Formatter().format("%.3f", distance);//使结果距离保留三位小数
        distance = Double.parseDouble(String.valueOf(format));

        return distance;
    }
}
