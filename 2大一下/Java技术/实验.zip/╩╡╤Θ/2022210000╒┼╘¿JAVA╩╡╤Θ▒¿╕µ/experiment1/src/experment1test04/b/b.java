package experment1test04.b;

import experment1test04.a.a;

public class b {
    String name;

    public static void main(String[] args) {
        a a= new a();
        System.out.println("b");
    }
}
