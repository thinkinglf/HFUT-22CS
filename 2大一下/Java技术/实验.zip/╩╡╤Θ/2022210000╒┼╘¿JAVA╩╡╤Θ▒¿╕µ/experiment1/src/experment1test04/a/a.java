package experment1test04.a;

public class a {
    String name;
    public static void main(String[] args) {
        System.out.println("a");
    }
}
