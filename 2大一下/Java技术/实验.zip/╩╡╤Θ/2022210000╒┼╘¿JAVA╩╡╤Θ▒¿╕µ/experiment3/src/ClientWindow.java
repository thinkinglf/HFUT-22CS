import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClientWindow extends JFrame {

    JPanel clientSettings;
    JTextField addressField;
    JTextField portField;
    JButton connectBtn;

    JPanel areaPanel;
    JTextArea messageArea;

    JPanel sendPanel;
    JTextField sendField;
    JButton sendBtn;

    Client client;

    public ClientWindow() {
        super("客户端");

        this.setSize(500, 300);
        this.setResizable(false);
        this.setLayout(new BorderLayout());


        initializeServerSettings();

        initializeAreaPanel();

        initializeSendPanel();


        this.add(clientSettings, BorderLayout.NORTH);
        this.add(areaPanel, BorderLayout.CENTER);
        this.add(sendPanel, BorderLayout.SOUTH);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        connectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int port = Integer.parseInt(portField.getText());
                    client = new Client(port, messageArea, addressField.getText());
                } catch (java.lang.NumberFormatException exception) {
                    messageArea.append("- 端口格式有误，请重新输入。\n");
                }

                System.out.println(portField.getText());
            }
        });

        sendBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(sendField.getText());
                client.sendMsg(sendField.getText());
                sendField.setText("");
            }
        });

    }

    private void initializeServerSettings() {
        clientSettings = new JPanel();
        addressField = new JTextField(20);
        portField = new JTextField(10);
        connectBtn = new JButton("Connect");
        clientSettings.setBorder(new EmptyBorder(10, 5, 10, 5));

        clientSettings.add(new JLabel("IP："));
        clientSettings.add(addressField);
        clientSettings.add(new JLabel("Port："));
        clientSettings.add(portField);
        clientSettings.add(connectBtn);
    }

    private void initializeSendPanel() {
        sendPanel = new JPanel();
        sendBtn = new JButton("Send");
        sendField = new JTextField(30);
        sendPanel.setBorder(new EmptyBorder(10, 5, 10, 5));

        sendPanel.add(new JLabel("Send："));
        sendPanel.add(sendField);
        sendPanel.add(sendBtn);
    }

    private void initializeAreaPanel() {
        areaPanel = new JPanel();
        messageArea = new JTextArea(9, 40);
        areaPanel.add(new JScrollPane(messageArea));
    }

}