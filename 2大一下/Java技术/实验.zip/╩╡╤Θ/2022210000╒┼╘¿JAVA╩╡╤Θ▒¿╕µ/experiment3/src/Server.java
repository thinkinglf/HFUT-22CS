import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

//服务器类，用于处理最初的PortWaiter的创建任务以及向客户端发送消息。
class Server extends Thread {
        Socket client;
        ServerSocket server;
        JTextArea messageArea;
        BufferedReader br;
        BufferedWriter bw;
        InputStream is;
        OutputStream os;
        int port;

        Server(int port, JTextArea msgArea) {
        this.port = port;
        this.messageArea = msgArea;
        this.start();
    }

    @Override
    public void run() {
        super.run();
        try {
            server = new ServerSocket(port);
            messageArea.append("- 服务已在端口 " + port + "上启动。\n");
            //从ServerSocket等待新连接的Socket。
            client = server.accept();
            messageArea.append("- " + client.getInetAddress().getLocalHost() + " 已连接到服务。\n");
            is = client.getInputStream();
            os = client.getOutputStream();
            br = new BufferedReader(new InputStreamReader(is));
            bw = new BufferedWriter(new OutputStreamWriter(os));
            while (true) {
                String newMsg = br.readLine();
                if (newMsg != null) {
                    messageArea.append(">> " + newMsg + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            if (e instanceof java.net.ConnectException)
                messageArea.append("- 服务启动失败，请重试或更换端口。" + "\n");
            else
                messageArea.append("- 与客户端的连接已断开，服务停止。\n");
        } finally {
            try {
                server.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void sendMsg(String msg) {
        System.out.println("sendMsg");
        try {
            bw.write(msg + "\n");
            bw.flush();
            messageArea.append("<< " + msg + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}