import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ServerWindow extends JFrame {

    JPanel serverSettings;
    JTextField portField;
    JButton startBtn;

    JPanel areaPanel;
    JTextArea messageArea;

    JPanel sendPanel;
    JTextField sendField;
    JButton sendBtn;

    Server server;

    public ServerWindow() {
        super("服务端");

        this.setSize(500, 300);
        this.setResizable(false);
        this.setLayout(new BorderLayout());

        initializeServerSettings();

        initializeAreaPanel();

        initializeSendPanel();


        this.add(serverSettings, BorderLayout.NORTH);
        this.add(areaPanel, BorderLayout.CENTER);
        this.add(sendPanel, BorderLayout.SOUTH);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        startBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int port = Integer.parseInt(portField.getText());
                    server = new Server(port, messageArea);
                } catch (java.lang.NumberFormatException exception) {
                    messageArea.append("- 端口格式有误，请重新输入。\n");
                }

                System.out.println(portField.getText());
            }
        });

        sendBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                server.sendMsg(sendField.getText());
                sendField.setText("");
            }
        });
    }

    private void initializeServerSettings() {
        serverSettings = new JPanel();
        portField = new JTextField(30);
        startBtn = new JButton("Start");
        serverSettings.setBorder(new EmptyBorder(10, 5, 10, 5));

        serverSettings.add(new JLabel("Port："));
        serverSettings.add(portField);
        serverSettings.add(startBtn);
    }

    private void initializeAreaPanel() {
        areaPanel = new JPanel();
        messageArea = new JTextArea(9, 40);
        areaPanel.add(new JScrollPane(messageArea));
    }

    private void initializeSendPanel() {
        sendPanel = new JPanel();
        sendBtn = new JButton("Send");
        sendField = new JTextField(30);
        sendPanel.setBorder(new EmptyBorder(10, 5, 10, 5));

        sendPanel.add(new JLabel("Send："));
        sendPanel.add(sendField);
        sendPanel.add(sendBtn);
    }
}