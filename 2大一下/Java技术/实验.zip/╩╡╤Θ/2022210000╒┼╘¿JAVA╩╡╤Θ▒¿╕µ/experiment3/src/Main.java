public class Main {
    public static void main(String[] args) {
        ServerWindow serverWindow = new ServerWindow();
        ClientWindow clientWindow = new ClientWindow();
    }
}