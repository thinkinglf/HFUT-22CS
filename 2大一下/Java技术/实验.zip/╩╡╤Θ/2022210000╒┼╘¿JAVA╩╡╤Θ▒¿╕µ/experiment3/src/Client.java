import javax.swing.*;
import java.io.*;
import java.net.Socket;

public class Client extends Thread {
    //客户端类
    Socket server;
    JTextArea messageArea;
    BufferedReader br;
    BufferedWriter bw;
    InputStream is;
    OutputStream os;
    int port;
    String address;

    Client(int port, JTextArea msgArea, String address) {
        this.port = port;
        this.messageArea = msgArea;
        this.address = address;
        this.start();
    }

    @Override
    public void run() {
        super.run();
        try {
            server = new Socket(address, port);
            messageArea.append("- 已连接到主机 " + server.getInetAddress().getLocalHost() + "\n");
            is = server.getInputStream();
            os = server.getOutputStream();
            br = new BufferedReader(new InputStreamReader(is));
            bw = new BufferedWriter(new OutputStreamWriter(os));
            while (true) {
                String newMsg = br.readLine();
                if (newMsg != null) {
                    messageArea.append(">> " + newMsg + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            if (e instanceof java.net.ConnectException)
                messageArea.append("- 无法连接到主机，请重试或检查地址和端口。" + "\n");
            else
                messageArea.append("- 与远程主机的连接已断开。\n");
        }
    }

    public void sendMsg(String msg) {
        System.out.println("sendMsg");
        try {
            bw.write(msg + "\n");
            bw.flush();
            messageArea.append("<< " + msg + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}




